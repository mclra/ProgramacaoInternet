import java.util.Scanner;

/**
 *
 * @author 20211134010036
 */
public class Main {
  static Scanner leitor;
  static int base;
  static int expoente;
  static int valor;
  static int resultado;

  public static void capturarValores(){
    System.out.println("Digite o valor da base:");
    base = leitor.nextInt();
    System.out.println("Digite o valor do expoente:");
    expoente = leitor.nextInt();
  }

  public static int potencia(int ba, int ex){
        resultado = base;
    for(int i = 1; i <= ex; i++){
      resultado = (ba * resultado);
  }
    return resultado;
  }
  
  public static void main(String[] args) {
   leitor = new Scanner(System.in);
   capturarValores();
    
   //int valor = potencia(base, expoente);
    System.out.println("O resultado da sua operação foi: " +resultado);
  
    
  }
}
